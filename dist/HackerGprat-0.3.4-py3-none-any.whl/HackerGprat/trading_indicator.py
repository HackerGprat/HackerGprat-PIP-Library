def avg( listOfNumbes ):
    return (sum(listOfNumbes) / len(listOfNumbes))


# a = [2,3,3,5,7,10]
# print( avg(a) )

if __name__ == '__main__':
    pass
